# Snake Game

## Overview

This project is a classic implementation of the Snake game using C++ with SDL2 for rendering. The game involves controlling a snake to eat food, which causes it to grow in size. The goal is to achieve the highest score possible without colliding with the snake's own body or the screen edges.

## Code Structure

- **`src/`**: Contains all the source code files.
  - **`main.cpp`**: The entry point of the application where the game loop starts.
  - **`game.cpp`**: Contains the main game logic and handling of the game state.
  - **`game.h`**: The header file for game logic, including declarations for game state management.
  - **`controller.cpp`**: Handles user input.
  - **`controller.h`**: Declares the `Controller` class for input handling.
  - **`renderer.cpp`**: Manages the rendering of the game state using SDL2.
  - **`renderer.h`**: Declares the `Renderer` class for drawing the game elements.
  - **`snake.cpp`**: Implements the `Snake` class, including movement and growth.
  - **`snake.h`**: Declares the `Snake` class with its attributes and methods.
  - **`game_logger.cpp`**: Implements the `GameLogger` class for logging game events.
  - **`game_logger.h`**: Declares the `GameLogger` class used for logging.

## New Features

### 1. OOP: Customized Snake Body Color

- **Description**: Added the ability for players to select the snake's color from predefined options. This feature enhances the game's customization and visual appeal.
- **Color Selection**: At the start of the game, players are prompted to select a color for the snake's body. The available color options are:
  - 1 for Green
  - 2 for Pink
  - 3 for White
  - 4 for Yellow
  - If the input is out of range from 1 to 4, the color is set to white (default).

### 2. Memory Management: Output Log File

- **Description**: Implemented logging functionality using `GameLogger` to track game events and output them to a log file.

- **File format**: ./build/game_log.txt

### 3. Concurrency: Concurrent Food Placement

- **Description**: Introduced multithreading to place food on the grid concurrently, ensuring that food is placed randomly every few seconds without blocking the main game loop.

## Rubric points

### 0. Loops, Functions, I/O

- **The project demonstrates an understanding of C++ functions and control structures.**:
  - Modification parts demonstrate this through the game loop in Game::Run(), which includes input handling, updating the game state, and rendering, while managing frame rates.

- **The project reads data from a file and process the data, or the program writes data to a file.**:
  - The GameLogger class writes log data to a file, satisfying this criterion.

- **The project accepts user input and processes the input.**:
  - The main.cpp file reads user input for choosing the snake color and processes it, meeting this requirement.

- **The project uses data structures and immutable variables.**:
  - Data structures such as std::vector are used in the Snake class for the body. Immutable variables are present, such as score in Game, which is updated through methods rather than being directly manipulated.

### 1. Object Oriented Programming

- **One or more classes are added to the project with appropriate access specifiers for class members.**:
  - Classes Game, GameLogger, and Snake are well-defined with appropriate access specifiers.

- **Class constructors utilize member initialization lists.**:
  - Constructors in Game and Snake use member initialization lists, e.g., Game::Game(...) initializes members like snake and engine using initialization lists.

- **Classes abstract implementation details from their interfaces.**:
  - Classes abstract implementation details well. For example, Game handles game logic and food placement, while GameLogger handles logging, both without exposing internal details.

- **Overloaded functions allow the same function to operate on different parameters.**:
  - The GameLogger::Log() function is overloaded to handle different types of messages, fulfilling this requirement.

- **Classes follow an appropriate inheritance hierarchy with virtual and override functions.**:
  - Not cover

- **Templates generalize functions or classes in the project.**:
  - The GameLogger::Log() method uses templates to handle different message types, meeting this criterion.

### 2. Memory Management

- **The project makes use of references in function declarations**:
  - The `Run` function in `Game` uses references: `void Run(Controller const &controller, Renderer &renderer, std::size_t target_frame_duration);`
  - The logger in the main function also uses references: `GameLogger logger("game_log.txt");`

- **The project uses destructors appropriately**:
  - The `GameLogger` class has a destructor that closes the log file if it's open, ensuring proper resource cleanup: `~GameLogger() { if (log_file_.is_open()) { log_file_.close(); } }`
  - The `Game` class uses default destructors, which is appropriate given that it uses smart pointers for resource management.

- **The project uses scope / Resource Acquisition Is Initialization (RAII) where appropriate**:
  - The use of `std::unique_ptr` in the `Game` class for managing the `GameLogger` instance ensures RAII. The `logger_` is automatically destroyed when the `Game` object goes out of scope.

- **The project follows the Rule of 5**:
  - The `Game` class explicitly defines the destructor, copy constructor, copy assignment operator, move constructor, and move assignment operator, fully adhering to the Rule of 5.

- **The project uses move semantics to move data instead of copying it, where possible**:
  - The `Game` class implements move constructors and move assignment operators, ensuring that resources are moved rather than copied when instances of `Game` are transferred.

- **The project uses smart pointers instead of raw pointers**:
  - The `Game` class uses `std::unique_ptr` to manage the `GameLogger` instance, avoiding the use of raw pointers.

### 3. Concurrency

- **Multithreading**:
  - The `Game` class now includes a `std::thread` named `food_thread_` to run the `FoodPlacementThread` method concurrently. This thread is started in the `Game` constructor and joins in the destructor to ensure proper cleanup.

- **Promise and Future**:
  - A `std::promise<void>` named `food_promise_` and a `std::future<void>` named `food_future_` are used to manage the lifecycle of the `food_thread_`. The `food_future_` is initialized with the future from `food_promise_`, allowing the thread to be notified when it should stop.

- **Mutex or Lock**:
  - A `std::mutex` named `food_mutex_` is used to synchronize access to shared resources (like the food location) in the `PlaceFood` method. The `std::lock_guard` ensures that the mutex is locked while accessing or modifying the food position and automatically unlocked when the lock goes out of scope.

- **A condition variable is used in the project.**:
  - Not cover