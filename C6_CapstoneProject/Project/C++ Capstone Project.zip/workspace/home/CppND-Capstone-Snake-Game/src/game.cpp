#include "game.h"
#include <iostream>
#include "SDL.h"
#include "game_logger.h"

Game::Game(std::size_t grid_width, std::size_t grid_height)
    : snake(grid_width, grid_height),
      engine(dev()),
      random_w(0, static_cast<int>(grid_width - 1)),
      random_h(0, static_cast<int>(grid_height - 1)),
      logger_(std::make_unique<GameLogger>("game_log.txt")),
      food_future_(food_promise_.get_future()) { // Initialize future
  PlaceFood(); // Place initial food
  food_thread_ = std::thread(&Game::FoodPlacementThread, this); // Start the food placement thread
}

Game::~Game() {
  if (food_thread_.joinable()) {
    food_promise_.set_value(); // Notify the thread to stop
    food_thread_.join(); // Ensure the thread finishes before destruction
  }
}

Game::Game(const Game& other)
    : snake(other.snake),
      food(other.food),
      engine(other.engine),
      random_w(other.random_w),
      random_h(other.random_h),
      score(other.score) {
}

Game& Game::operator=(const Game& other) {
    if (this != &other) {
        snake = other.snake;
        food = other.food;
        engine = other.engine;
        random_w = other.random_w;
        random_h = other.random_h;
        score = other.score;
    }
    return *this;
}

Game::Game(Game&& other) noexcept
    : snake(std::move(other.snake)),
      food(other.food),
      engine(std::move(other.engine)),
      random_w(std::move(other.random_w)),
      random_h(std::move(other.random_h)),
      score(other.score),
      logger_(std::move(other.logger_)),
      food_thread_(std::move(other.food_thread_)),
      food_promise_(std::move(other.food_promise_)),
      food_future_(std::move(other.food_future_)) {
}

Game& Game::operator=(Game&& other) noexcept {
  if (this != &other) {
    snake = std::move(other.snake);
    food = other.food;
    engine = std::move(other.engine);
    random_w = std::move(other.random_w);
    random_h = std::move(other.random_h);
    score = other.score;
    logger_ = std::move(other.logger_);
    food_thread_ = std::move(other.food_thread_);
    food_promise_ = std::move(other.food_promise_);
    food_future_ = std::move(other.food_future_);
  }
  return *this;
}

void Game::Run(Controller const &controller, Renderer &renderer,
               std::size_t target_frame_duration) {
  Uint32 title_timestamp = SDL_GetTicks();
  Uint32 frame_start;
  Uint32 frame_end;
  Uint32 frame_duration;
  int frame_count = 0;
  bool running = true;

  while (running) {
    frame_start = SDL_GetTicks();

    // Input, Update, Render - the main game loop.
    controller.HandleInput(running, snake);
    Update();
    renderer.Render(snake, food);

    frame_end = SDL_GetTicks();

    // Keep track of how long each loop through the input/update/render cycle
    // takes.
    frame_count++;
    frame_duration = frame_end - frame_start;

    // After every second, update the window title.
    if (frame_end - title_timestamp >= 1000) {
      renderer.UpdateWindowTitle(score, frame_count);
      frame_count = 0;
      title_timestamp = frame_end;
    }

    // If the time for this frame is too small (i.e. frame_duration is
    // smaller than the target ms_per_frame), delay the loop to
    // achieve the correct frame rate.
    if (frame_duration < target_frame_duration) {
      SDL_Delay(target_frame_duration - frame_duration);
    }
  }
}

void Game::PlaceFood() {
  std::lock_guard<std::mutex> lock(food_mutex_);
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y)) {
      food.x = x;
      food.y = y;
      return;
    }
  }
}

void Game::Update() {
  if (!snake.alive) return;

  snake.Update();

  int new_x = static_cast<int>(snake.head_x);
  int new_y = static_cast<int>(snake.head_y);

  // Check if there's food over here
  if (food.x == new_x && food.y == new_y) {
    score++;
    PlaceFood();
    // Grow snake and increase speed.
    snake.GrowBody();
    snake.speed += 0.02;
  }
}

void Game::FoodPlacementThread() {
  while (food_future_.wait_for(std::chrono::seconds(0)) == std::future_status::timeout) {
    std::this_thread::sleep_for(std::chrono::seconds(5)); // Place food every 5 seconds
    PlaceFood();
  }
}

int Game::GetScore() const { return score; }
int Game::GetSize() const { return snake.size; }
