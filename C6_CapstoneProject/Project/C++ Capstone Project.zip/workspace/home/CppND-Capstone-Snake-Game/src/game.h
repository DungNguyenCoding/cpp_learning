#ifndef GAME_H
#define GAME_H

#include <memory>
#include <random>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>
#include "SDL.h"
#include "controller.h"
#include "renderer.h"
#include "game_logger.h"

class Game {
 public:
  Game(std::size_t grid_width, std::size_t grid_height);
  ~Game(); // Destructor for Rule of 5
  Game(const Game& other); // Copy constructor for Rule of 5
  Game& operator=(const Game& other); // Copy assignment for Rule of 5
  Game(Game&& other) noexcept; // Move constructor for Rule of 5
  Game& operator=(Game&& other) noexcept; // Move assignment for Rule of 5

  void Run(Controller const &controller, Renderer &renderer,
           std::size_t target_frame_duration);
  int GetScore() const;
  int GetSize() const;
  
  // Set snake body color
  void SetSnakeColor(Snake::Color new_color) { snake.SetColor(new_color); }

 private:
  Snake snake;
  SDL_Point food;

  std::random_device dev;
  std::mt19937 engine;
  std::uniform_int_distribution<int> random_w;
  std::uniform_int_distribution<int> random_h;

  int score{0};
  std::unique_ptr<GameLogger> logger_; // Smart pointer for logging
  std::thread food_thread_; // Thread for concurrent food placement
  std::mutex food_mutex_; // Mutex for synchronizing food access
  std::condition_variable food_cv_; // Condition variable for signaling
  std::promise<void> food_promise_; // Promise to signal food placement
  std::future<void> food_future_; // Future to receive food placement signal

  void PlaceFood();
  void Update();
  void FoodPlacementThread();
};

#endif // GAME_H
