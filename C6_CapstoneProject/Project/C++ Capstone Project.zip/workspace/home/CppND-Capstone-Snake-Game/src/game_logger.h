#ifndef GAME_LOGGER_H
#define GAME_LOGGER_H

#include <fstream>
#include <memory>

class GameLogger {
public:
    explicit GameLogger(const std::string &filename) : log_file_(filename) {}

    // Delete copy constructor and copy assignment operator
    GameLogger(const GameLogger &) = delete;
    GameLogger &operator=(const GameLogger &) = delete;

    // Allow move constructor and move assignment operator
    GameLogger(GameLogger &&) noexcept = default;
    GameLogger &operator=(GameLogger &&) noexcept = default;

    ~GameLogger() {
        if (log_file_.is_open()) {
            log_file_.close();
        }
    }

    template<typename T>
    void Log(const T &message) {
        if (log_file_.is_open()) {
            log_file_ << message << std::endl;
        }
    }

private:
    std::ofstream log_file_;
};

#endif // GAME_LOGGER_H
