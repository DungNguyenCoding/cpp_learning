#include "game_logger.h"
#include <iostream>

GameLogger::GameLogger(const std::string& filename) {
  log_file_.open(filename, std::ios::out | std::ios::app);
  if (!log_file_) {
    throw std::runtime_error("Unable to open log file: " + filename);
  }
}

GameLogger::~GameLogger() {
  if (log_file_.is_open()) {
    log_file_.close();
  }
}

void GameLogger::Log(const std::string& message) {
  std::cout << message << std::flush;
  if (log_file_.is_open()) {
    log_file_ << message;
  }
}
