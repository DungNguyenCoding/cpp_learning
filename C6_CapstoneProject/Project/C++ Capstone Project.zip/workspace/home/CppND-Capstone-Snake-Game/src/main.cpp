#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include "game_logger.h"

int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  GameLogger logger("game_log.txt");  // Create a GameLogger instance

  // Ask the player to choose a color for snake body
  int color_choice;
  std::cout << "Choose the snake color:\n";
  std::cout << "1. Green\n";
  std::cout << "2. Pink\n";
  std::cout << "3. White\n";
  std::cout << "4. Yellow\n";
  std::cout << "Enter your choice (1-4): ";
  std::cin >> color_choice;

  Snake::Color snake_color;
  switch (color_choice) {
    case 1:
      snake_color = Snake::Color::kGreen;
      break;
    case 2:
      snake_color = Snake::Color::kPink;
      break;
    case 3:
      snake_color = Snake::Color::kWhite;
      break;
    case 4:
      snake_color = Snake::Color::kYellow;
      break;
    default:
      snake_color = Snake::Color::kWhite;
      break;
  }
  
  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  Controller controller;
  Game game(kGridWidth, kGridHeight);
  game.SetSnakeColor(snake_color);  // Set the snake body color
    switch (snake_color) {
    case (Snake::Color::kGreen):
      logger.Log("Snake body is set to green.\n");
      break;
    case (Snake::Color::kPink):
      logger.Log("Snake body is set to pink.\n");
      break;
    case (Snake::Color::kWhite):
      logger.Log("Snake body is set to white.\n");
      break;
    case (Snake::Color::kYellow):
      logger.Log("Snake body is set to yellow.\n");
      break;
    default:
      logger.Log("Invalid choice, defaulting to white color.\n");
      break;
  }
  game.Run(controller, renderer, kMsPerFrame);

  // Log game termination details
  logger.Log("Game has terminated successfully!\n");
  logger.Log("Score: " + std::to_string(game.GetScore()) + "\n");
  logger.Log("Size: " + std::to_string(game.GetSize()) + "\n");

  return 0;
}
