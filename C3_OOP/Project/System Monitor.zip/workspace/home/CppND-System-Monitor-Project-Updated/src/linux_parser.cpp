#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, version, kernel;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() {
  string line;
  string key;
  float value;
  float memtotal = 0.0;
  float memfree = 0.0;
  std::ifstream filestream(kProcDirectory + kMeminfoFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "MemTotal:") {
        memtotal = value;
      } else if (key == "MemFree:") {
        memfree = value;
      }
      // Exit the loop early if both values are found
      if (memtotal > 0 && memfree > 0) {
        break;
      }
    }
  }
  return memtotal > 0 ? (memtotal - memfree) / memtotal : 0.0;
}

// TODO: Read and return the system uptime
long LinuxParser::UpTime() {
  long value = 0.0;
  string line;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  if (stream.is_open()) {
    if (std::getline(stream, line)) {
      std::istringstream linestream(line);
      linestream >> value;
    }
  }
  return value;
}

// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() {
  vector<string> cpu;
  string line, key, value;
  std::ifstream fileStream(kProcDirectory + kStatFilename);
  if (fileStream.is_open()) {
    while (std::getline(fileStream, line)) {
      std::istringstream linestream(line);
      linestream >> key;
      if (key == "cpu") {
        while (linestream >> value) {
          cpu.emplace_back(value);
        }
        break;
      }
    }
  }
  return cpu;
}

// Get the total CPU usage of an application from /proc/pid/stat
// Refer to: https://stackoverflow.com/questions/16726779/how-do-i-get-the-total-cpu-usage-of-an-application-from-proc-pid-stat/16736599#16736599
float LinuxParser::ProcessCpuUtilization(int pid) { 
  float uptime = (float)LinuxParser::UpTime();
  float hertz_value = (float)sysconf(_SC_CLK_TCK);
  float totalTime = 0.0, seconds = 0.0, cpu_usage = 0.0;
  string line, key, value;
  vector<string> processorStat;
  std::ifstream fileStream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (fileStream.is_open()) {
    std::getline(fileStream, line);
    std::istringstream linestream(line);
    while(linestream >> value){
      processorStat.emplace_back(value);
    }
  }
  if (processorStat.size() > ProcessStatIdx::starttime) {
    totalTime = stof(processorStat[ProcessStatIdx::utime]) + stof(processorStat[ProcessStatIdx::stime]) + stof(processorStat[ProcessStatIdx::cutime]) + stof(processorStat[ProcessStatIdx::cstime]);
    seconds = uptime - (stof(processorStat[ProcessStatIdx::starttime]) / hertz_value);
    if (seconds > 0) {
      cpu_usage = ( ( totalTime / hertz_value ) / seconds );
    }
  }
  return cpu_usage;
}

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() {
  int totalprocesses = 0;
  string line, key;
  int value;
  std::ifstream fileStream(kProcDirectory + kStatFilename);
  if (fileStream.is_open()) {
    while(std::getline(fileStream, line)) {
      std::istringstream linestream(line);
      while(linestream >> key >> value) {
        if(key == "processes") {
          totalprocesses = value;
          break;
        }
      }
    }
  }
  return totalprocesses;
}

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() {
  int runningprocesses = 0;
  string line, key;
  int value;
  std::ifstream fileStream(kProcDirectory + kStatFilename);
  if (fileStream.is_open()) {
    while(std::getline(fileStream, line)) {
      std::istringstream linestream(line);
      while(linestream >> key >> value) {
        if(key == "procs_running") {
          runningprocesses = value;
          break;
        }
      }
    }
  }
  return runningprocesses;
}

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) {
  string line;
  string cmd;
  std::ifstream stream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  if (stream.is_open()) {
    std::getline(stream, cmd);
  }
  return cmd;
}

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) {
  string line, key, ram_value_kb;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while(linestream >> key) {
        if (key == "VmSize:") {
          linestream >> ram_value_kb;
          break;
        }
      }
    }
  }
  long ram_value_kb_long = std::stol(ram_value_kb);
  long ram_value_mb = ram_value_kb_long / 1024;
  return std::to_string(ram_value_mb);
}

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) {
  string line, key, uid;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while(linestream >> key) {
        if (key == "Uid:") {
          linestream >> uid;
          break;
        }
      }
    }
  }
  return uid;
}

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) {
  string line, user, character, value;
  string username = "";
  string uid = LinuxParser::Uid(pid);
  std::ifstream fileStream(kPasswordPath);
  if (fileStream.is_open()) {
    while(std::getline(fileStream, line)){
      std::replace(line.begin(), line.end(), ':', ' ');
      std::istringstream linestream(line);
      linestream >> user >> character >> value;
      if(value == uid) {
        username = user;
        break;
      }
    }
  }
  return username; 
}

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) {
  string line, value;
  long upTimeValue = 0;
  std::ifstream fileStream(kProcDirectory + std::to_string(pid) + kStatFilename);
  if (fileStream.is_open()) {
    while(std::getline(fileStream, line)){
      std::istringstream linestream(line);
      for(int i = 0; i <22; i++){
          linestream >> value;
      }
      upTimeValue = stol(value);
    }
  }
  return LinuxParser::UpTime() - upTimeValue/sysconf(_SC_CLK_TCK);
}