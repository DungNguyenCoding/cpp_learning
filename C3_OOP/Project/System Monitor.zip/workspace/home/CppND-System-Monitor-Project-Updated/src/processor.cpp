#include <vector>
#include <string>
#include <stdexcept>
#include <iostream>
#include "processor.h"
#include "linux_parser.h"

using std::stof;
using std::vector;
using std::string;

// Return the aggregate CPU utilization
float Processor::Utilization() {
  vector<string> cpu = LinuxParser::CpuUtilization();
  
  // Check if cpu vector has the necessary number of elements
  if (cpu.size() <= LinuxParser::CPUStates::kSteal_) {
    return 0.0;  // return 0 or some other indication of error
  }
  
  float idletime = 0.0;
  float activetime = 0.0;

  try {
    idletime = stof(cpu[LinuxParser::CPUStates::kIdle_]) + stof(cpu[LinuxParser::CPUStates::kIOwait_]);
    activetime = stof(cpu[LinuxParser::CPUStates::kUser_]) + stof(cpu[LinuxParser::CPUStates::kNice_]) + 
                 stof(cpu[LinuxParser::CPUStates::kSystem_]) + stof(cpu[LinuxParser::CPUStates::kIRQ_]) + 
                 stof(cpu[LinuxParser::CPUStates::kSoftIRQ_]) + stof(cpu[LinuxParser::CPUStates::kSteal_]);
  } catch (const std::invalid_argument& e) {
    return 0.0;  // return 0 or some other indication of error
  } catch (const std::out_of_range& e) {
    return 0.0;  // return 0 or some other indication of error
  }

  return activetime / (idletime + activetime);
}